import "package:flutter/material.dart";
import "package:pokeapi_ex9/models/pokemon_list_model.dart";
import "package:pokeapi_ex9/screens/pokemon_detail.dart";

class PokemonTile extends StatelessWidget {
  final PokemonListModel pokemonListModel;

  const PokemonTile({required this.pokemonListModel, super.key});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(pokemonListModel.name,
          style: TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(pokemonListModel.url),
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => PokemonDetail(name: pokemonListModel.name),
      )),
    );
  }
}
