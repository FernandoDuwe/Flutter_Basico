import "package:flutter/material.dart";
import "package:pokeapi_ex9/repositories/pokemon_repository.dart";

class PokemonDetail extends StatelessWidget {
  final String name;

  const PokemonDetail({required this.name, super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Detalhes"),
      ),
      body: FutureBuilder(
        future: PokemonRepository.getPokemon(name),
        builder: (context, snapshot) {
          if (snapshot.hasError)
            return Center(
              child: Text(snapshot.error.toString()),
            );

          if (!snapshot.hasData)
            return Center(
              child: CircularProgressIndicator(),
            );

          return ListView(
            children: [
              Container(
                color: Colors.yellow,
                alignment: Alignment.center,
                height: 200,
                child: Image.network(snapshot.data!.image,
                    height: double.infinity, width: double.infinity,
                fit: BoxFit.fitHeight,),
              ),
              ListTile(
                leading: Icon(Icons.insert_drive_file_outlined),
                title: Text("Nome"),
                subtitle: Text(snapshot.data!.name),
              ),
              ListTile(
                leading: Icon(Icons.monitor_weight_outlined),
                title: Text("Peso"),
                subtitle: Text(snapshot.data!.weight.toString()),
              )
            ],
          );
        },
      ),
    );
  }
}
