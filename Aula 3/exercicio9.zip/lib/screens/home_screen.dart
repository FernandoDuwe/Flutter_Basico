import "package:flutter/material.dart";
import "package:pokeapi_ex9/repositories/pokemon_repository.dart";
import "package:pokeapi_ex9/widgets/pokemon_tile.dart";

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int page = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pokemons - Página ${page}"),
      ),
      body: FutureBuilder(
        future: PokemonRepository.getAll(page),
        builder: (context, snapshot) {
          if (snapshot.hasError)
            return Center(
              child: Text(
                snapshot.error.toString(),
                style: TextStyle(color: Colors.red),
              ),
            );

          if (!snapshot.hasData)
            return Center(
              child: CircularProgressIndicator(),
            );

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) =>
                PokemonTile(pokemonListModel: snapshot.data![index]),
          );
        },
      ),
      floatingActionButton: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton(onPressed: page != 1 ? () {
            setState(() {
              page--;
            });
          } : null,
            backgroundColor: (page == 1 ? Colors.grey : Colors.blue),
          child: Icon(Icons.navigate_before),
          ),
          SizedBox(width: 10),
          FloatingActionButton(onPressed: () {
            setState(() {
              page++;
            });
          },
          child: Icon(Icons.navigate_next),
          )
        ],
      ),
    );
  }
}
