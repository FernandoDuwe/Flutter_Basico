import "dart:convert";

import "package:http/http.dart" as http;
import "package:pokeapi_ex9/models/pokemon_list_model.dart";

import "../models/pokemon_detail_model.dart";

const int POKEMON_ITEM_COUNT = 20;

class PokemonRepository {
  static Future<List<PokemonListModel>> getAll([int currentPage = 1]) async {
    // https://pokeapi.co/api/v2/pokemon?limit=20
    Uri uri = Uri.https("pokeapi.co", "/api/v2/pokemon", {
      "limit": POKEMON_ITEM_COUNT.toString(),
      "offset": ((currentPage - 1) * POKEMON_ITEM_COUNT).toString()
    });

    http.Response response = await http.get(uri);

    var result = jsonDecode(response.body);

    List<PokemonListModel> list = [];

    (result["results"] as List<dynamic>)
        .forEach((element) => list.add(PokemonListModel.fromJson(element)));

    return list;
  }

  static Future<PokemonDetailModel> getPokemon(String name) async {
    Uri uri = Uri.https("pokeapi.co", "/api/v2/pokemon/$name");

    http.Response response = await http.get(uri);

    var result = jsonDecode(response.body);

    return PokemonDetailModel.fromJson(result);
  }
}
