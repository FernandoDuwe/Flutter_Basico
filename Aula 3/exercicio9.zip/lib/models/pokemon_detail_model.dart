class PokemonDetailModel {
  String name = "";
  int weight = 0;
  String image = "";

  PokemonDetailModel.fromJson(Map<String, dynamic> json) {
    name = json["name"];
    weight = json["weight"];
    image = json["sprites"]["front_default"];
  }
}