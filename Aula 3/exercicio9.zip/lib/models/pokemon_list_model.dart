class PokemonListModel {
  String name = "";
  String url = "";

  PokemonListModel({ required this.name, required this.url });

  PokemonListModel.fromJson(Map<String, dynamic> json) {
    name = json["name"];
    url = json["url"];
  }
}